import java.util.*;
/**
 * Idea extended from https://newcircle.com/bookshelf/java_fundamentals_tutorial/generics_collections
 * Additional coded added
 * @author Maria Zontak
 */
public class ArrayTypeError {

    public static void main(String[] args) {

        //Let's start from illustrating Array Type problems
        //First consider the following
        Object thing = new Dog(); //since Dog is an Object we can assign it to variable of type Object
        System.out.println("Since Dog is an Object we can assign it to variable of type Object:");
        System.out.println(thing);
        System.out.println("Remeber we cannot ask Objects to do things they do not know, unless we cast:");

        //thing.identify();  //this will NOT compile
        ((Dog) thing).identify();  //this WILL compile
        System.out.println("We can REassign to the SAME variable a new object Cat:");
        thing = new Cat(); //we can REassign to the same variable a new object Cat
        System.out.println(thing);
        //thing.identify();
        System.out.println("Keep this in mind. Let's try to do the same with ARRAY of Dogs :");
        //till now everything worked perfectly let's try the same with an Array of Dogs
        // Create an array of three anonymous dogs
        Dog[] kennel = {new Dog(), new Dog(), new Dog()};
        // Let them all speak
        System.out.println("This is our ARRAY of Dogs :");
        for (Dog d : kennel) d.speak();
        System.out.println("Dogs are Objects so we should be able to reference our ARRAY of Dogs with an Object reference: Object[] things  = kennel");
        // Dogs are Objects, so this should work
        Object[] things = kennel;
        /* A Cat is an Object, so we should be able to add one to the
         * things array. Note that the following does NOT cause a
         * compiler error! Instead it throws a RUNTIME exception,
         * ArrayStoreException.
         */
        System.out.println("A Cat is an Object, so we should be able to add a Cat to the things array: things[0] = new Cat();");
        System.out.println("This line compiles, but it throws a RUNTIME exception, ArrayStoreException --> UNCOMMENT in the code");
        // things[0] = new Cat(); //if you want to continue COMMENT OUT THIS LINE
        System.out.println("Similar will happen if you create an array of Animal type instead of Object");
        System.out.println("The problem is: you are trying to reference the SAME array of objects with two different types, one is a subclass (Dog[]) of another (Oject[])");
        System.out.println("So you can accidently add incomatible type (Cat) through Object[] reference and then try to do something with it using Dog[] reference and language!!!  - which is bad");
        //uncomment if you want to verify that it does not matter what is the super class - nothing specific to Object.
        //Animal[] animals = kennel;
        //animals[0]= new Cat();
        System.out.println("Note that this would NOT have happened if we had started directly from Array of Objects: Object[] objects = { new Dog(), new Dog(), new Dog()}; ");
        Object[] objects = {new Dog(), new Dog(), new Dog()};
        for (Object d : objects) ((Animal) d).speak();
        objects[0] = new Cat();
        System.out.println("Setting the first element to Cat works!  objects[0] = new Cat(); --> ");
        for (Object d : objects) ((Animal) d).speak();
        System.out.println("Now please CONTINUE to ArrayListGenerics");


    }
}