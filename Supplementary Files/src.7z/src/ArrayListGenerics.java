import java.util.*;
/**
 * we are gioing to show here that ArrayList are TYPE SAFE, but this imposes certain limitations 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ArrayListGenerics {

    public static void main(String[] args) {
        System.out.println("PLEASE RUN ArrayTypeError before reading this. If you have done so - you may proceed");
        //Let's start from illustrating that Poymorphism WORKS
        System.out.println("Let's start from illustrating that Poymorphism WORKS:");
        System.out.println("We are going to construct animal List of 2 Dogs and 1 Cat.");
        List<Animal> animals = new ArrayList<Animal>(3);
        animals.add(new Dog());
        animals.add(new Dog());
        animals.add(new Cat());
        //GREAT review of Polimorphism and Static, Dynamic types
        System.out.println("Just a reminder - the objects within ArrayList<Animal> animals have a STATIC type of ANIMAL - but their Dynamic type can be any subtype");
        System.out.println("This is the idea of polymorphism");
        System.out.println("You can communicate with these objects using ONLY Animal language (methods), but they will reply based on their Dynamic Types ");
        System.out.println("Verifying animals in the list");
        verifyClass(animals);
        //However,  List<Animal> is NOT POLYMORPHIC with  List<Object> (generally  List<SubClass> is NOT POLYMOPRHIC with  List<SupserClass>).
        System.out.println("HOWEVER:");
        System.out.println("You CANNOT reference List<Animal> with a varable of Type  List<Object>");
        System.out.println("You CANNOT pass variable of List<Animal> to a method that accepts List<Object> type");
        System.out.println("This is done to ensure type safety of ArrayList as opposed to Array - you will get compile error for");
        System.out.println("printCollectionDoesNotWork(animals); ---> TRY TO UNCOOMMENT IN THE CODE");
        System.out.println("where  public static void printCollectionDoesNotWork(List<Object> objectList) ");
        //        printCollectionDoesNotWork(animals); //COMMENT this OUT if you want to continue with the example
        //addCat(animals2);
        System.out.println("If you want to create a method that accepts an ArrayList<subclass> you need to use WildCards operator ? ");
        System.out.println("As  in printCollectionWorks(List<? extends Animal> animalList)");
        printCollectionWorks(animals);
        System.out.println("Above we passed List<Animal> to List<? extends Object> and it worked!");

        System.out.println("Now consider another List of Cats:");
        List<Cat> cats = new ArrayList<Cat>(2);
        cats.add(new Cat());
        cats.add(new Cat());
        for (Cat c: cats) c.speak();

        System.out.println("Below we are adding cats to animals using addAll method similar to one that we once implemented");
        animals.addAll(cats);
        System.out.println("Here what our animals have to say:");
        for (Animal a: animals) a.speak();
        System.out.println("Using List<? extends Animal> in identifyAnimals we can use this method with any List<subclass of Animal>");
        System.out.println("Identifying animals:");
        identifyAnimals(animals);
        System.out.println("Identifying cats");
        identifyAnimals(cats);
        System.out.println("However, once you use reference List<? extends Animal>, you CANNOT add new objects to this list - to ensure type safety");
        System.out.println("To see that - uncomment in the code -  public static void addCat(List<? extends Animal> animalList) and the lines in the end of the main ");
        System.out.println("If you do so - you will get a compile error");
        //uncomment below and addCat(List<? extends Animal> animalList)
        //addCat(animals);
        //addCat(cats); //Will NOT work with either animals or cats!!!
        System.out.println("The END");
    }




    public static void printCollectionDoesNotWork(List<Object> objectList){
        for (Object o: objectList) System.out.println(o.getClass());               
    }
 
   public static void printCollectionWorks(List<? extends Object> objectList){
        for (Object o: objectList) System.out.println(o.getClass());                    
    }

    public static void identifyAnimals(List<? extends Animal> animalList){
        for (int i = 0; i < animalList.size(); i++)
            animalList.get(i).identify();                        
    }
    
 /*  public static void addCat(List<? extends Animal> animalList) {
       animalList.add(new Cat());  // will violate type safety //What about  new Animal()?
   }
*/
    public static void verifyClass(List<Animal> objectList){
        for (Animal o: objectList) System.out.println(o.getClass());
    }  
}



