package main.java.edu.neu.ccs.cs5004;

/**
 * Created by therapon on 5/24/16.
 */
public class UseCircle {


//    public Circle createAnInvalidCircle(){
//        return new Circle(new Posn(0,0), -1);
//    }
}
