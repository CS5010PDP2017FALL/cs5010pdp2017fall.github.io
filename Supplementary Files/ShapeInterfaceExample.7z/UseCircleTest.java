package main.java.edu.neu.ccs.cs5004;

import main.java.edu.neu.ccs.cs5004.UseCircle;
import org.junit.Before;
import org.junit.Test;

public class UseCircleTest {
    private UseCircle uc;

    @Before
    public void setUp() throws Exception {
        this.uc = new UseCircle();
    }

    @Test
    public void createAnInvalidCircle() throws Exception {
//        uc.createAnInvalidCircle();
    }

}