package main.java.edu.neu.ccs.cs5004;

/**
 * Represents a Circle in our shapes program.
 */
public class Circle extends AbstractShape {
    private Integer radius;

    public Circle(Posn pin, Integer radius) {
        super(pin);
        if (radius <= 0) {
            throw new InvalidRadiusException("Radius must be > 0, given: " + radius);
        }
        this.radius = radius;
    }


    /**
     * Getter for property 'radius'.
     *
     * @return Value for property 'radius'.
     */
    public Integer getRadius() {
        return this.radius;
    }

    @Override
    public Shape moveX(Integer dx) {
        return null;
    }

    @Override
    public Shape moveY(Integer dy) {
        return null;
    }

    @Override
    public Integer area() {
        return null;
    }

    @Override
    public Integer circumference() {
        return null;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        Circle circle = (Circle) o;

        return getRadius() != null ? getRadius().equals(circle.getRadius()) : circle.getRadius() == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (getRadius() != null ? getRadius().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Circle{"
            + "radius=" + radius
            + "} " + super.toString();
    }


}
