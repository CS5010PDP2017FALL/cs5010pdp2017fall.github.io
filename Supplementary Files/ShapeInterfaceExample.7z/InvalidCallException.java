package edu.neu.ccs.cs5004;

/**
 * Created by therapon on 5/23/16.
 */
public class InvalidCallException extends RuntimeException {

    public InvalidCallException(String msg){
        super(msg);
    }
}
