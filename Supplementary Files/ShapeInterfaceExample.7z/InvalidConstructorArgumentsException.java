package main.java.edu.neu.ccs.cs5004;

/**
 * Created by therapon on 5/23/16.
 */
public class InvalidConstructorArgumentsException extends RuntimeException {

    /**
     * {@inheritDoc}
     */
    public InvalidConstructorArgumentsException(String message) {
        super(message);
    }
}
