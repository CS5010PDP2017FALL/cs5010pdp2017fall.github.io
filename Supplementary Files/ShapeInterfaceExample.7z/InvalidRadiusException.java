package main.java.edu.neu.ccs.cs5004;

/**
 * Created by therapon on 5/24/16.
 */
public class InvalidRadiusException extends RuntimeException{

    public InvalidRadiusException(String s) {
        super(s);
    }
}
