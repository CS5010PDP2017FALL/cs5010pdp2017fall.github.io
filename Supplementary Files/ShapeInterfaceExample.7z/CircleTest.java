package main.java.edu.neu.ccs.cs5004;

import main.java.edu.neu.ccs.cs5004.Circle;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CircleTest {
    private Circle incorrectCircle;
    private Circle circleRadius10;

    @Before
    public void setUp() throws Exception {
//        this.incorrectCircle = new Circle(new Posn(1,1),-1);
        this.circleRadius10 = new Circle(new Posn(10,10), 10);

    }

    @Test
    public void testGetRadius() throws Exception {
        Assert.assertEquals(this.circleRadius10.getRadius(), new Integer(10));
    }

    @Test(expected=InvalidRadiusException.class)
    public void testInvalidRadius() throws Exception {
        this.incorrectCircle = new Circle(new Posn(0,0), -1);
    }

}