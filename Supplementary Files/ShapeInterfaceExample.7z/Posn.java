package main.java.edu.neu.ccs.cs5004;

/**
 * Repersents a cartesian coordinate.
 *
 */
public class Posn {

    private Integer x;
    private Integer y;

    public Posn(Integer x, Integer y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Getter for property 'x'.
     *
     * @return Value for property 'x'.
     */
    public Integer getX() {
        return this.x;
    }

    /**
     * Getter for property 'y'.
     *
     * @return Value for property 'y'.
     */
    public Integer getY() {
        return this.y;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Posn posn = (Posn) o;

        if (getX() != null ? !getX().equals(posn.getX()) : posn.getX() != null) return false;
        return getY() != null ? getY().equals(posn.getY()) : posn.getY() == null;
    }

    @Override
    public int hashCode() {
        int result = getX() != null ? getX().hashCode() : 0;
        result = 31 * result + (getY() != null ? getY().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Posn{"
            + "x=" + x
            + ", y=" + y
            + '}';
    }


}

