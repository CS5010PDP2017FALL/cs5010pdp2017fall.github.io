package main.java.edu.neu.ccs.cs5004;

/**
 * Represents the common properties of a shape
 */
public abstract class AbstractShape implements Shape {
    protected Posn pin;

    public AbstractShape(Posn pin) {
        this.pin = pin;
    }

    /**
     * Getter for property 'pin'.
     *
     * @return Value for property 'pin'.
     */
    public Posn getPin() {
        return this.pin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AbstractShape that = (AbstractShape) o;

        return getPin() != null ? getPin().equals(that.getPin()) : that.getPin() == null;
    }

    @Override
    public int hashCode() {
        return getPin() != null ? getPin().hashCode() : 0;
    }

    @Override
    public String toString() {
        return "AbstractShape{"
            + "pin=" + pin
            + '}';
    }


}
