package main.java.edu.neu.ccs.cs5004;


/**
 * Represents a rectangle in our shapes program.
 */
public class Rectangle extends AbstractShape {

    private Integer width;
    private Integer height;

    public Rectangle(Posn pin, Integer width, Integer height) {
        super(pin);
        this.width = width;
        this.height = height;
    }

    /**
     * Getter for property 'width'.
     *
     * @return Value for property 'width'.
     */
    public Integer getWidth() {
        return this.width;
    }

    /**
     * Getter for property 'height'.
     *
     * @return Value for property 'height'.
     */
    public Integer getHeight() {
        return this.height;
    }

    @Override
    public Shape moveX(Integer dx) {
        return null;
    }

    @Override
    public Shape moveY(Integer dy) {
        return null;
    }

    @Override
    public Integer area() {
        return null;
    }

    @Override
    public Integer circumference() {
        return null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        Rectangle rectangle = (Rectangle) o;

        if (getWidth() != null ? !getWidth().equals(rectangle.getWidth()) : rectangle.getWidth() != null)
            return false;
        return getHeight() != null ? getHeight().equals(rectangle.getHeight()) : rectangle.getHeight() == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (getWidth() != null ? getWidth().hashCode() : 0);
        result = 31 * result + (getHeight() != null ? getHeight().hashCode() : 0);
        return result;
    }
}
